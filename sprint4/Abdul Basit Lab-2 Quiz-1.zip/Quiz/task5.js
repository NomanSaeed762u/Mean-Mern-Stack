
class Car {
    constructor(make, model, year) {
      this.make = make;
      this.model = model;
      this.year = year;
    }
  
    Get_Car_specification() {
      return (`Make: ${this.make}, Model: ${this.model}, Year: ${this.year}`);
    }
  }
  
  let myCar = new Car("Toyota", "Any Model", 2021);
  console.log(myCar.Get_Car_specification()); 